package com.example.project_7_contactbook.MainActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.example.project_7_contactbook.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{

    RecyclerView recyclerView;
    FloatingActionButton floatingActionButton;
    LinearLayout callList , contactList;

    ArrayList<ContactModel> contactModelArrayList = new ArrayList<>();

    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.RecyclerView);
        floatingActionButton = findViewById(R.id.FlotingActionButton);
        callList = findViewById(R.id.CallList);
        contactList = findViewById(R.id.ContactList);


        dbHelper = new DBHelper(MainActivity.this);

        contactList.setOnClickListener(view -> {

            Intent Inext;
            Inext = new Intent(MainActivity.this , MainActivity_2.class);
            startActivity(Inext);

        });


    }
}